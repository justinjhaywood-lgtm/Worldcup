
(function(){
  var KEY = "ploughmans_hub_v3_pubs";
  var seed = [
    {
      id:"black-bear-inn",
      name:"The Black Bear Inn",
      region:"Wales",
      address:"Bettws Newydd, Usk NP15 1JN",
      rating:5,
      summary:"A standout Welsh ploughman's with sharp cheddar, pickled onions and a proper local ale.",
      image:"https://images.unsplash.com/photo-1559339352-11d035aa65de?auto=format&fit=crop&w=1200&q=80"
    },
    {
      id:"fitzherbert-arms",
      name:"Fitzherbert Arms",
      region:"Staffordshire",
      address:"Swynnerton, Staffordshire ST15 0RA",
      rating:4,
      summary:"A smarter gastro-style board with Scotch egg, artisan bread and a cracking pale ale pairing.",
      image:"https://images.unsplash.com/photo-1514933651103-005eec06c04b?auto=format&fit=crop&w=1200&q=80"
    },
    {
      id:"sussex-ox",
      name:"The Sussex Ox",
      region:"South East",
      address:"Milton Street, East Sussex BN7 3AP",
      rating:4,
      summary:"A sunshine-friendly ploughman's with local cheese and a very decent chutney hit.",
      image:"https://images.unsplash.com/photo-1574062358326-64151965f7c3?auto=format&fit=crop&w=1200&q=80"
    }
  ];
  function getPubs(){
    try{
      var pubs = JSON.parse(localStorage.getItem(KEY) || "[]");
      if(!Array.isArray(pubs) || pubs.length===0){
        localStorage.setItem(KEY, JSON.stringify(seed));
        return seed.slice();
      }
      return pubs;
    }catch(e){
      localStorage.setItem(KEY, JSON.stringify(seed));
      return seed.slice();
    }
  }
  function savePubs(pubs){
    localStorage.setItem(KEY, JSON.stringify(pubs));
  }
  function onions(n){
    n = Number(n)||0;
    return "🧅".repeat(n);
  }
  function slugify(s){
    return (s||"").toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/(^-|-$)/g,"");
  }
  function renderCards(targetId, pubs){
    var el = document.getElementById(targetId);
    if(!el) return;
    el.innerHTML = pubs.map(function(p){
      return '<article class="card">'+
        '<img src="'+p.image+'" alt="'+p.name+'">'+
        '<div class="badge">'+p.region+'</div>'+
        '<h3>'+p.name+'</h3>'+
        '<p class="muted">'+(p.address||"")+'</p>'+
        '<p><strong>'+onions(p.rating)+'</strong> ('+p.rating+'/5)</p>'+
        '<p>'+p.summary+'</p>'+
        '<p><a class="button" href="pub.html?id='+p.id+'">View pub</a></p>'+
      '</article>';
    }).join("");
  }
  function addPubFromForm(){
    var name = document.getElementById("name").value.trim();
    var region = document.getElementById("region").value.trim();
    var address = document.getElementById("address").value.trim();
    var rating = Number(document.getElementById("rating").value||0);
    var summary = document.getElementById("summary").value.trim();
    var image = document.getElementById("image").value.trim() || "https://images.unsplash.com/photo-1514933651103-005eec06c04b?auto=format&fit=crop&w=1200&q=80";
    var status = document.getElementById("status");
    if(!name || !region){
      if(status) status.innerHTML = '<div class="panel">Please enter at least a pub name and region.</div>';
      return false;
    }
    var pubs = getPubs();
    var dup = pubs.find(function(p){
      return p.name.toLowerCase()===name.toLowerCase() && (p.address||"").toLowerCase()===address.toLowerCase();
    });
    if(dup){
      if(status) status.innerHTML = '<div class="panel">Possible duplicate found: <strong>'+dup.name+'</strong></div>';
      return false;
    }
    pubs.unshift({
      id: slugify(name),
      name:name,
      region:region,
      address:address,
      rating: rating || 1,
      summary: summary || "New submission awaiting full write-up.",
      image:image
    });
    savePubs(pubs);
    if(status) status.innerHTML = '<div class="panel">Pub saved locally in this browser.</div>';
    return true;
  }
  function renderPubDetail(){
    var target = document.getElementById("pub-detail");
    if(!target) return;
    var params = new URLSearchParams(window.location.search);
    var id = params.get("id");
    var pubs = getPubs();
    var p = pubs.find(function(x){ return x.id===id; }) || pubs[0];
    target.innerHTML = '<section class="hero">'+
      '<div class="panel">'+
      '<div class="badge">'+p.region+'</div>'+
      '<h1>'+p.name+'</h1>'+
      '<p class="muted">'+(p.address||"")+'</p>'+
      '<p><strong>'+onions(p.rating)+'</strong> ('+p.rating+'/5)</p>'+
      '<p>'+p.summary+'</p>'+
      '<h2>Ploughman\'s focus</h2>'+
      '<ul><li>Cheese and chutney balance</li><li>Proper bread quality</li><li>Pickled onion score</li><li>Pint pairing potential</li></ul>'+
      '</div>'+
      '<div><img src="'+p.image+'" alt="'+p.name+'"></div>'+
      '</section>';
  }
  window.PloughmansHub = {
    getPubs:getPubs,
    savePubs:savePubs,
    renderCards:renderCards,
    addPubFromForm:addPubFromForm,
    renderPubDetail:renderPubDetail
  };
})();
